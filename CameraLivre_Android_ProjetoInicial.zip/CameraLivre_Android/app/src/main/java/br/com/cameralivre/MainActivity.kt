package br.com.cameralivre

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.camera.core.Preview
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private lateinit var recordButton: Button
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var recording = false

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results[Manifest.permission.CAMERA] == true &&
            results[Manifest.permission.RECORD_AUDIO] == true) {
            startCamera()
        } else {
            status.text = "Permissões da câmera e do microfone são necessárias."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (needed.all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) {
            startCamera()
        } else {
            permissions.launch(needed)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            setBackgroundColor(0xFF080808.toInt())
        }
        val title = TextView(this).apply {
            text = "CÂMERA LIVRE"
            textSize = 25f
            setTextColor(0xFFD9A521.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 6)
        }
        val subtitle = TextView(this).apply {
            text = "Gravação simples • Sem assinatura"
            textSize = 13f
            setTextColor(0xFFBBBBBB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 14)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        status = TextView(this).apply {
            text = "Preparando câmera…"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 12)
        }
        recordButton = Button(this).apply {
            text = "●  INICIAR GRAVAÇÃO"
            setTextColor(0xFF080808.toInt())
            setBackgroundColor(0xFFD9A521.toInt())
            setOnClickListener { if (recording) stopRecording() else startRecording() }
        }
        val note = TextView(this).apply {
            text = "Protótipo inicial: gravação contínua. Gravação retroativa, voz, Bluetooth e tela apagada ainda precisam ser implementados e testados."
            textSize = 11f
            setTextColor(0xFFAAAAAA.toInt())
            gravity = Gravity.CENTER
            setPadding(4, 12, 4, 4)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(previewView)
        root.addView(status)
        root.addView(recordButton)
        root.addView(note)
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(Quality.HD))
                    .build()
                videoCapture = VideoCapture.withOutput(recorder)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, videoCapture)
                status.text = "Câmera pronta"
            } catch (e: Exception) {
                status.text = "Não foi possível iniciar a câmera."
                Toast.makeText(this, e.localizedMessage ?: "Erro da câmera", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun startRecording() {
        val capture = videoCapture ?: run {
            status.text = "A câmera ainda não está pronta."
            return
        }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "CameraLivre_$stamp")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CameraLivre")
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        var pending = capture.output.prepareRecording(this, output)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED) {
            pending = pending.withAudioEnabled()
        }
        activeRecording = pending.start(ContextCompat.getMainExecutor(this)) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    recording = true
                    recordButton.text = "■  PARAR GRAVAÇÃO"
                    status.text = "Gravando…"
                }
                is VideoRecordEvent.Finalize -> {
                    recording = false
                    activeRecording = null
                    recordButton.text = "●  INICIAR GRAVAÇÃO"
                    status.text = if (!event.hasError()) "Vídeo salvo em Filmes/CameraLivre"
                        else "Falha ao salvar vídeo (${event.error})"
                }
            }
        }
    }

    private fun stopRecording() {
        activeRecording?.stop()
        status.text = "Finalizando vídeo…"
    }

    override fun onDestroy() {
        activeRecording?.stop()
        super.onDestroy()
    }
}
