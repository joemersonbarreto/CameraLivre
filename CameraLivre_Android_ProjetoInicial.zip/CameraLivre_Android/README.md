# Câmera Livre — protótipo Android

Interface preta e dourada e gravação contínua básica usando CameraX.

## Abrir
1. Instale o Android Studio.
2. Abra a pasta `CameraLivre_Android`.
3. Aguarde a sincronização do Gradle.
4. Execute em um aparelho Android físico e conceda acesso à câmera e ao microfone.

## Estado atual
Este é um protótipo inicial, não uma cópia do Ok Câmera e não um APK final. Implementa visual e gravação contínua básica para validar o projeto.

Ainda não implementado:
- gravação retroativa real de 30 segundos;
- comandos de voz contínuos;
- controles Bluetooth;
- serviço de gravação em segundo plano/tela apagada;
- testes específicos no Xiaomi POCO C65.

Esses recursos exigem implementação adicional, permissões e testes no aparelho. A gravação em segundo plano está sujeita às regras da versão do Android/MIUI/HyperOS instalada.
